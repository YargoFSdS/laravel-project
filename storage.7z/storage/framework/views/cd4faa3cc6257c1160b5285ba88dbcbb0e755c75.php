

<?php $__env->startSection('title','Cadastrar Post'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('posts.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo $__env->make('admin.posts._partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>

<?php if(session('message')): ?>
    <div>
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yargo\example-project\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>