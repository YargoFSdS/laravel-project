

<?php $__env->startSection('title','Farmácias'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-sm my-4 p-1 pr-0 flex items-center">
    <a href="<?php echo e(route('produtos.create')); ?>" class="uppercase p-3 rounded bg-blue-500 text-blue-50 max-w-max shadow-sm hover:shadow-lg"> 
        Cadastrar Produto
    </a>
</div>

<form action="<?php echo e(route('produtos.search')); ?>" method="post" class="bg-white">
    <?php echo csrf_field(); ?>
    <div class="max-w-sm my-4 p-1 pr-0 flex items-center">
        <input type="text" name="search" placeholder="Filtrar:" class="flex-1 appearance-none rounded shadow p-3 text-grey-dark mr-2 focus:outline-none">
        <button type="submit" class="uppercase p-3 rounded bg-blue-500 text-blue-50 max-w-max shadow-sm hover:shadow-lg">Filtrar</button>
    </div>
</form>
<?php if(session('message')): ?>
    <div>
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?>

<hr>
<table class="table-auto" style="width:100%;">
    <thead>
        <tr>
        <th class="text-left">Imagem</th>
        <th class="text-left">Descrição</th>
        <th class="text-left">Preço</th>
        <th class="text-left">Desconto</th>
        <th class="text-left">Categoria</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><img src="<?php echo e(url("storage/{$p->imagem}")); ?>"  alt="<?php echo e($p->descricao); ?>" style="max-width:100px;" /></td>
        <td><?php echo e($p->descricao); ?></td>
        <td><?php echo e($p->preco); ?></td>
        <td><?php echo e($p->desconto); ?></td>
        <td><?php echo e($p->desc_categoria); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php if(isset($filters)): ?>
    <?php echo e($produtos->appends($filters)->links()); ?>

<?php else: ?>
    <?php echo e($produtos->links()); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yargo\example-project\resources\views/admin/produtos/index.blade.php ENDPATH**/ ?>