
<?php $__env->startSection('title','Editar Post'); ?>

<?php $__env->startSection('content'); ?>
<h1>Detalhes do Post </h1>

<ul>
    <li><?php echo e($post->title); ?></li>
    <li><?php echo e($post->content); ?></li>
</ul>

<form action="<?php echo e(route('posts.destroy',$post->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="_method" value="delete">
    <button type="submit">Deletar o Post</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Yargo\example-project\resources\views/admin/posts/show.blade.php ENDPATH**/ ?>